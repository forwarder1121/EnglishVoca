package mainPart;

import java.awt.Point;

public class DroppingWord {
	Word word;
	Point pos;
	
	public DroppingWord(Word word, Point pos) {
		super();
		this.word = word;
		this.pos = pos;
	}
	
}
